flex analyse_lexical_return.l
gcc lex.yy.c -o analyse_lexical
